import Calculator from './components/calculator';

function App() {
  return (
    <div>
      <Calculator />
    </div>
  );
}

export default App;
